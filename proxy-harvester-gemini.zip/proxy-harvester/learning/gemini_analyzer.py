#!/usr/bin/env python3
"""Manual, privacy-conscious Gemini analysis of proxy-harvester run statistics."""
from __future__ import annotations
import json
import os
import sys
from collections import Counter
from pathlib import Path
import requests

ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / "output" / "run_report.json"
OUT = ROOT / "learning"
MODEL = os.getenv("GEMINI_MODEL", "gemini-3.8-flash")


def build_summary(report: dict) -> dict:
    nodes = report.get("nodes", [])
    stats = report.get("statistics", {})
    protocols = Counter()
    countries = Counter()
    xray = Counter()
    singbox = Counter()
    speeds = []
    tcp = []
    for n in nodes:
        protocols[str(n.get("protocol", "unknown"))] += 1
        countries[str(n.get("country_code", "ZZ"))] += 1
        xray[str(n.get("xray", "unknown"))] += 1
        singbox[str(n.get("sing_box", "unknown"))] += 1
        if isinstance(n.get("speed_mbps"), (int, float)):
            speeds.append(float(n["speed_mbps"]))
        if isinstance(n.get("tcp_ms"), (int, float)):
            tcp.append(float(n["tcp_ms"]))
    # Deliberately omit host, IP, port, name, source, URI, credentials and SNI.
    return {
        "generated_at_utc": report.get("generated_at_utc"),
        "run_statistics": stats,
        "output_file_counts": report.get("output_files", {}),
        "node_count": len(nodes),
        "protocol_counts": dict(protocols),
        "country_counts_top_20": dict(countries.most_common(20)),
        "xray_status_counts": dict(xray),
        "sing_box_status_counts": dict(singbox),
        "tcp_latency_ms": {"count": len(tcp), "median": sorted(tcp)[len(tcp)//2] if tcp else None},
        "speed_mbps": {"count": len(speeds), "median": sorted(speeds)[len(speeds)//2] if speeds else None},
    }


def main() -> int:
    key = os.getenv("GEMINI_API_KEY", "").strip()
    if not key:
        print("ERROR: Add GEMINI_API_KEY to GitHub Actions secrets.", file=sys.stderr)
        return 2
    if not REPORT.exists():
        print("ERROR: output/run_report.json not found. Run Refresh proxy lists first.", file=sys.stderr)
        return 3
    try:
        report = json.loads(REPORT.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"ERROR: Cannot read report ({type(exc).__name__}).", file=sys.stderr)
        return 4
    summary = build_summary(report)
    prompt = (
        "Ты анализируешь агрегированную статистику проекта сбора публичных прокси. "
        "Нужно: 1) найти узкие места сбора и проверки; 2) объяснить различия результатов Xray и sing-box; "
        "3) предложить конкретные безопасные изменения параметров/алгоритма; 4) указать риски ложных выводов; "
        "5) составить короткий план экспериментов. Не выдумывай факты и не объявляй серверы рабочими без проверки. "
        "Не предлагай сканировать случайные IP-диапазоны. Отделяй выводы из статистики от гипотез. "
        "Ответ на русском языке, с разделами Наблюдения, Проблемы, Рекомендации, Эксперименты.\n\n"
        "Обезличенная статистика запуска (без IP, хостов, портов, URI и ключей):\n" +
        json.dumps(summary, ensure_ascii=False, indent=2)
    )
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:generateContent"
    try:
        response = requests.post(
            url, params={"key": key},
            json={"contents": [{"parts": [{"text": prompt}]}],
                  "generationConfig": {"temperature": 0.2, "maxOutputTokens": 5000}},
            timeout=180,
        )
        if response.status_code != 200:
            print(f"Gemini API error {response.status_code}: {response.text[:1200]}", file=sys.stderr)
            return 5
        data = response.json()
        parts = data.get("candidates", [{}])[0].get("content", {}).get("parts", [])
        answer = "\n".join(p.get("text", "") for p in parts if p.get("text"))
        if not answer.strip():
            print("ERROR: Gemini returned an empty response.", file=sys.stderr)
            return 6
        OUT.mkdir(parents=True, exist_ok=True)
        (OUT / "gemini_analysis.md").write_text(
            "# Gemini analysis\n\nModel: `" + MODEL + "`\n\n" + answer + "\n", encoding="utf-8")
        (OUT / "gemini_input_summary.json").write_text(
            json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        usage = data.get("usageMetadata", {})
        print(f"Analysis saved. Prompt tokens: {usage.get('promptTokenCount', 'n/a')}; "
              f"output tokens: {usage.get('candidatesTokenCount', 'n/a')}")
        return 0
    except requests.RequestException as exc:
        print(f"ERROR: Gemini request failed ({type(exc).__name__}).", file=sys.stderr)
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
